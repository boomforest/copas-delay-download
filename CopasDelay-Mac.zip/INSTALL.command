#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p ~/Library/Audio/Plug-Ins/Components
rm -rf ~/Library/Audio/Plug-Ins/Components/"Copas Delay.component"
cp -R "$DIR/Copas Delay.component" ~/Library/Audio/Plug-Ins/Components/
xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/Components/"Copas Delay.component"
mkdir -p ~/Library/Audio/Plug-Ins/VST3
rm -rf ~/Library/Audio/Plug-Ins/VST3/"Copas Delay.vst3"
cp -R "$DIR/Copas Delay.vst3" ~/Library/Audio/Plug-Ins/VST3/
xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/VST3/"Copas Delay.vst3"
killall -9 AudioComponentRegistrar 2>/dev/null
echo "Copas Delay installed for Logic and Ableton."
echo "Logic: Audio Units > Casa de Copas > Copas Delay."
echo "Ableton: Plug-ins > VST3 > Casa de Copas > Copas Delay (turn on VST3 in Preferences > Plug-ins and hit Rescan if you don't see it)."
