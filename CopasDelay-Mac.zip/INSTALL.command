#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p ~/Library/Audio/Plug-Ins/Components
rm -rf ~/Library/Audio/Plug-Ins/Components/"Copas Delay.component"
cp -R "$DIR/Copas Delay.component" ~/Library/Audio/Plug-Ins/Components/
xattr -dr com.apple.quarantine ~/Library/Audio/Plug-Ins/Components/"Copas Delay.component"
killall -9 AudioComponentRegistrar 2>/dev/null
echo "Copas Delay installed. Open Logic: it's under Audio Units > Casa de Copas > Copas Delay."
